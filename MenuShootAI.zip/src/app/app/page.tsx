"use client";

import { useState, useCallback } from "react";
import Link from "next/link";
import { SignInButton, SignUpButton, SignedIn, SignedOut, UserButton, useUser } from "@clerk/nextjs";
import { useQuery } from "convex/react";
import { api } from "../../../convex/_generated/api";
import { BuyButton } from "@/components/BuyButton";
import { ART_DIRECTION_STYLES } from "@/lib/prompts";

export default function AppPage() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [style, setStyle] = useState<string>("editorial");
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFile = useCallback((f: File | null) => {
    setFile(f);
    setResult(null);
    setError(null);
    if (f) {
      const reader = new FileReader();
      reader.onload = () => setPreview(reader.result as string);
      reader.readAsDataURL(f);
    } else {
      setPreview(null);
    }
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const f = e.dataTransfer.files[0];
      if (f && f.type.startsWith("image/")) handleFile(f);
      else setError("Please upload an image file (JPEG, PNG, etc.)");
    },
    [handleFile]
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const f = e.target.files?.[0];
      if (f) handleFile(f);
      e.target.value = "";
    },
    [handleFile]
  );

  const handleTransform = async () => {
    if (!file) {
      setError("Please upload a photo first.");
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const formData = new FormData();
      formData.append("image", file);
      formData.append("style", style);
      const res = await fetch("/api/transform", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Transform failed");
      if (data.image) setResult(data.image);
      else throw new Error("No image returned");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownload = () => {
    if (!result) return;
    const a = document.createElement("a");
    a.href = result;
    a.download = `menushoot-${style}-${Date.now()}.png`;
    a.click();
  };

  const handleReset = () => {
    handleFile(null);
    setResult(null);
    setError(null);
  };

  const styles = Object.values(ART_DIRECTION_STYLES);
  const { user } = useUser();
  const credits = useQuery(
    api.users.getCredits,
    user?.id ? { clerkId: user.id } : "skip"
  );

  return (
    <div className="min-h-screen bg-cream text-charcoal flex flex-col">
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 md:px-12 py-5 bg-cream/90 backdrop-blur-sm border-b border-brown/10">
        <Link href="/" className="font-serif text-xl text-brown tracking-tight">
          Menu<span className="text-terracotta italic">Shoot</span>.ai
        </Link>
        <div className="flex items-center gap-6">
          <Link href="/#pricing" className="text-muted text-sm font-medium hover:text-terracotta transition-colors hidden md:block">
            Pricing
          </Link>
          <SignedOut>
            <SignInButton>
              <button className="text-muted text-sm font-medium hover:text-terracotta">Sign In</button>
            </SignInButton>
            <SignUpButton>
              <button className="bg-terracotta text-white py-2.5 px-5 rounded text-sm font-medium hover:bg-brown">Get Started</button>
            </SignUpButton>
          </SignedOut>
          <SignedIn>
            {credits !== undefined && (
              <span className="text-muted text-sm mr-2">{credits} credits</span>
            )}
            <Link href="/#pricing" className="bg-terracotta text-white py-2 px-4 rounded text-sm font-medium hover:bg-brown transition-colors shrink-0">
              Buy Credits
            </Link>
            <UserButton afterSignOutUrl="/" />
          </SignedIn>
        </div>
      </nav>

      <main className="flex-1 pt-24 px-6 pb-16 max-w-5xl mx-auto w-full">
        <SignedIn>
          <div className="mb-8 p-5 rounded-lg bg-warm-white border border-brown/10">
            <p className="text-brown font-medium mb-3">
              {credits !== undefined && credits < 1 ? "You need credits to transform images" : "Add more credits"}
            </p>
            <div className="flex flex-wrap gap-3">
              <BuyButton productId="trial" variant="outline" compact>
                3 for $99
              </BuyButton>
              <BuyButton productId="full" variant="filled" compact>
                25 for $549
              </BuyButton>
              <BuyButton productId="agency" variant="outline" compact>
                75/mo for $999
              </BuyButton>
            </div>
          </div>
        </SignedIn>

        <div className="text-center mb-10">
          <p className="text-terracotta text-xs font-medium tracking-[0.18em] uppercase mb-3">AI-Powered Food Photography</p>
          <h1 className="font-serif text-3xl md:text-4xl text-brown leading-tight mb-3">
            Upload a food photo.
            <br />
            <em className="text-terracotta">Get a hero shot.</em>
          </h1>
          <p className="text-muted text-base max-w-md mx-auto">
            Choose a style, upload your photo, and receive a professionally transformed image in seconds.
          </p>
        </div>

        {!preview ? (
          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            className={`border-2 border-dashed rounded-lg p-12 md:p-16 text-center transition-colors cursor-pointer ${
              isDragging ? "border-terracotta bg-terracotta/5" : "border-muted/40 hover:border-muted hover:bg-warm-white/50"
            }`}
          >
            <input type="file" accept="image/*" onChange={handleInputChange} className="hidden" id="upload" />
            <label htmlFor="upload" className="cursor-pointer block">
              <span className="text-4xl mb-3 block">📸</span>
              <p className="font-serif text-lg text-brown mb-1">Drag & drop your food photo</p>
              <p className="text-muted text-sm">or click to browse</p>
            </label>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-warm-white border border-brown/10 rounded-lg p-5">
              <p className="text-xs tracking-[0.12em] uppercase text-muted font-medium mb-3">Art Direction</p>
              <div className="flex flex-wrap gap-2">
                {styles.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setStyle(s.id)}
                    className={`px-4 py-2 rounded text-sm font-medium transition-all ${
                      style === s.id ? "bg-terracotta text-white" : "bg-cream text-muted hover:text-brown border border-brown/10 hover:border-terracotta/40"
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="rounded-lg overflow-hidden border border-brown/10 bg-warm-white">
                <p className="text-xs tracking-widest uppercase text-muted px-4 py-2.5 border-b border-brown/10">Before</p>
                <div className="aspect-[4/3] bg-cream relative">
                  <img src={preview} alt="Original" className="w-full h-full object-contain" />
                </div>
              </div>
              <div className="rounded-lg overflow-hidden border border-brown/10 bg-warm-white">
                <p className="text-xs tracking-widest uppercase text-muted px-4 py-2.5 border-b border-brown/10">After</p>
                <div className="aspect-[4/3] bg-cream relative flex items-center justify-center">
                  {isLoading ? (
                    <div className="flex flex-col items-center gap-3">
                      <div className="w-9 h-9 border-2 border-terracotta border-t-transparent rounded-full animate-spin" />
                      <p className="text-muted text-sm">Transforming…</p>
                    </div>
                  ) : result ? (
                    <img src={result} alt="Transformed" className="w-full h-full object-contain" />
                  ) : (
                    <p className="text-muted text-sm">Click Transform</p>
                  )}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-3 justify-center">
              <button
                onClick={handleTransform}
                disabled={isLoading}
                className="px-8 py-3.5 rounded bg-terracotta text-white font-medium hover:bg-brown disabled:opacity-50 disabled:cursor-not-allowed transition-all hover:-translate-y-0.5 hover:shadow-lg"
              >
                {isLoading ? "Transforming…" : "Transform"}
              </button>
              {result && (
                <button onClick={handleDownload} className="px-8 py-3.5 rounded border border-gold text-gold font-medium hover:bg-gold/10">
                  Download
                </button>
              )}
              <button onClick={handleReset} className="px-8 py-3.5 rounded border border-muted/50 text-muted hover:border-muted hover:text-brown">
                Start Over
              </button>
            </div>
          </div>
        )}

        {error && (
          <div className="mt-6 p-4 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">{error}</div>
        )}
      </main>
    </div>
  );
}
